"""Task 4 - Investment portfolio tracker with CSV logging.

Current prices come from (in order):
  1. yfinance (if installed and internet available)  -> pip install yfinance
  2. sample_prices.csv (offline fallback)
  3. manual input
Tickers are validated against constituents.csv (S&P 500 list).
"""
import csv
import os
from datetime import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
CONSTITUENTS = os.path.join(HERE, "constituents.csv")
SAMPLE_PRICES = os.path.join(HERE, "sample_prices.csv")
OUTPUT = os.path.join(HERE, "portfolio_summary.csv")


def load_valid_tickers():
    try:
        with open(CONSTITUENTS, newline="", encoding="utf-8") as f:
            return {row["Symbol"]: row["Security"] for row in csv.DictReader(f)}
    except OSError:
        return {}


def load_sample_prices():
    try:
        with open(SAMPLE_PRICES, newline="", encoding="utf-8") as f:
            return {r["Symbol"]: float(r["Price"]) for r in csv.DictReader(f)}
    except (OSError, KeyError, ValueError):
        return {}


def live_price(ticker):
    try:
        import yfinance as yf
        hist = yf.Ticker(ticker).history(period="1d")
        if not hist.empty:
            return float(hist["Close"].iloc[-1])
    except Exception:
        pass
    return None


def get_current_price(ticker, sample):
    price = live_price(ticker)
    if price is not None:
        return price, "live"
    if ticker in sample:
        return sample[ticker], "sample"
    while True:
        try:
            return float(input(f"  Enter current price for {ticker}: ")), "manual"
        except ValueError:
            print("  Invalid number.")


def read_float(prompt, positive=True):
    while True:
        try:
            v = float(input(prompt))
            if positive and v <= 0:
                print("  Must be greater than 0.")
                continue
            return v
        except ValueError:
            print("  Please enter a valid number.")


def collect_positions(valid):
    positions = {}
    print("Enter your holdings (leave ticker empty to finish).")
    while True:
        ticker = input("\nTicker symbol: ").strip().upper()
        if not ticker:
            break
        if valid and ticker not in valid:
            print(f"  '{ticker}' not found in S&P 500 list - adding anyway.")
        buy = read_float("  Buy price: ")
        qty = read_float("  Quantity : ")
        if ticker in positions:  # merge into average cost
            p = positions[ticker]
            total_qty = p["qty"] + qty
            p["buy"] = (p["buy"] * p["qty"] + buy * qty) / total_qty
            p["qty"] = total_qty
        else:
            positions[ticker] = {"buy": buy, "qty": qty}
    return positions


def analyse(positions, sample):
    rows = []
    for t, p in positions.items():
        cur, src = get_current_price(t, sample)
        invested = p["buy"] * p["qty"]
        value = cur * p["qty"]
        rows.append({
            "Ticker": t, "Quantity": p["qty"], "BuyPrice": round(p["buy"], 2),
            "CurrentPrice": round(cur, 2), "Invested": round(invested, 2),
            "CurrentValue": round(value, 2),
            "GainLoss": round(value - invested, 2),
            "GainLossPct": round((value - invested) / invested * 100, 2),
            "PriceSource": src,
        })
    return rows


def print_report(rows):
    print("\n" + "=" * 78)
    print(f"{'Ticker':<8}{'Qty':>8}{'Buy':>10}{'Now':>10}{'Invested':>12}{'Value':>12}{'P/L %':>10}")
    print("-" * 78)
    for r in rows:
        print(f"{r['Ticker']:<8}{r['Quantity']:>8g}{r['BuyPrice']:>10.2f}{r['CurrentPrice']:>10.2f}"
              f"{r['Invested']:>12.2f}{r['CurrentValue']:>12.2f}{r['GainLossPct']:>+9.2f}%")
    inv = sum(r["Invested"] for r in rows)
    val = sum(r["CurrentValue"] for r in rows)
    pct = (val - inv) / inv * 100 if inv else 0
    print("-" * 78)
    print(f"Total invested: {inv:,.2f} | Portfolio value: {val:,.2f} | Overall: {val - inv:+,.2f} ({pct:+.2f}%)")
    print("=" * 78)
    return inv, val, pct


def log_to_csv(rows, inv, val, pct):
    new_file = not os.path.exists(OUTPUT)
    stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    fields = ["Timestamp"] + list(rows[0].keys())
    try:
        with open(OUTPUT, "a", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=fields)
            if new_file:
                w.writeheader()
            for r in rows:
                w.writerow({"Timestamp": stamp, **r})
            w.writerow({"Timestamp": stamp, "Ticker": "TOTAL", "Invested": round(inv, 2),
                        "CurrentValue": round(val, 2), "GainLoss": round(val - inv, 2),
                        "GainLossPct": round(pct, 2)})
        print(f"Transaction summary saved to {os.path.basename(OUTPUT)}")
    except PermissionError:
        print("Could not write CSV - close the file if it is open in Excel.")


def main():
    valid = load_valid_tickers()
    sample = load_sample_prices()
    positions = collect_positions(valid)
    if not positions:
        print("No holdings entered.")
        return
    rows = analyse(positions, sample)
    inv, val, pct = print_report(rows)
    log_to_csv(rows, inv, val, pct)


if __name__ == "__main__":
    main()
